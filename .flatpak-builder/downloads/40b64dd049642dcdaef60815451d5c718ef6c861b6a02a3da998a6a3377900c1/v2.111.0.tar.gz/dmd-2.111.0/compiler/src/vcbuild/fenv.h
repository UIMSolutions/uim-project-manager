
#include <float.h>

#define isnan _isnan
