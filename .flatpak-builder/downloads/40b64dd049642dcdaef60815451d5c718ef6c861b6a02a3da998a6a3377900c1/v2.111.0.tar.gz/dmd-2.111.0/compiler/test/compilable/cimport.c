// https://issues.dlang.org/show_bug.cgi?id=22666

__import core.stdc.stdarg;
__import imports.impcimport;

int foo()
{
    va_list x;
    return 1 + A;
}
