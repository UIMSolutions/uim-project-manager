/* REQUIRED_ARGS: -P=-DABC=3
 */

_Static_assert(ABC == 3, "1");
