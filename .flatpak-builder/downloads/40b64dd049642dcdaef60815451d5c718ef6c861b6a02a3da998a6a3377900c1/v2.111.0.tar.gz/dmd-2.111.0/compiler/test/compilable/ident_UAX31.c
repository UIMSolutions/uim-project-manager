// REQUIRED_ARGS: -identifiers-importc=UAX31

// verify that the UAX31 identifier set is applied.

int \u00F8ide\u00F9nt;
int øideùnt2;
