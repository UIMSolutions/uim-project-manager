// REQUIRED_ARGS: -identifiers-importc=all

// verify that the All identifier set is applied.

int \u00F8ide\u00F9nt;
int \u00AAide\u00B5nt;
int \u00A8ide\u00AFnt;
int \u00F8ide\u00F9nt;
