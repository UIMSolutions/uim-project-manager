// REQUIRED_ARGS: -identifiers-importc=c11

// verify that the C11 identifier set is applied.

int \u00A8ide\u00AFnt;
int ¨ide¯nt;
