// REQUIRED_ARGS: -identifiers-importc=c99

// verify that the C99 identifier set is applied.

int \u00AAide\u00B5nt;
int ªideµnt2;
