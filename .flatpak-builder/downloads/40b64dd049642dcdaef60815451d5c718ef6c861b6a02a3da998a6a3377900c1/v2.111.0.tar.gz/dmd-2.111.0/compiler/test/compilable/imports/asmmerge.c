void fun22() asm ("test1");
void fun22()
{

}

extern int xs[] asm("test2");
int xs[1];
