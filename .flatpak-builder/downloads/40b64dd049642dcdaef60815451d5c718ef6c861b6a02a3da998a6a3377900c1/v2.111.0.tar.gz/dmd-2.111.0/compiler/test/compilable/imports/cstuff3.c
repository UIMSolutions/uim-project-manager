// check bugs in importing C files

int squared(int a)
{
    return a * a;
}
