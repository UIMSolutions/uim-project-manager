typedef struct S { int x; } T;
