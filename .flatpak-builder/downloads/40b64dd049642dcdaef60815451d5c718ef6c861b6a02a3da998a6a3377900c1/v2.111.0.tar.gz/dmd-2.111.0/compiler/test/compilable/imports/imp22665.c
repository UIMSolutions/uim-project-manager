enum E { A };
