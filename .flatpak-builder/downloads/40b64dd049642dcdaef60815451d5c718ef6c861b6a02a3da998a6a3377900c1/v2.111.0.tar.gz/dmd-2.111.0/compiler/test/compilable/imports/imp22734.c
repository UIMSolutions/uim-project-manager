typedef enum { C } E;

int a = C;
