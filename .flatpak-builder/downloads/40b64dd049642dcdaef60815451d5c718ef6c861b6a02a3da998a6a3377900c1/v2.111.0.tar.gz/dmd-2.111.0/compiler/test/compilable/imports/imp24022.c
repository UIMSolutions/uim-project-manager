// https://issues.dlang.org/show_bug.cgi?id=24022
typedef enum {
    A = 1,
    B,
} E;
