
enum E { A = 3 };
