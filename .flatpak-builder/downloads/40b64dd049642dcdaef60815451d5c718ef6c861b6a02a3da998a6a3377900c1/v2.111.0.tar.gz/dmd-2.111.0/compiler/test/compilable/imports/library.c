typedef enum SomeEnum
{
    foo = 0,
    bar = -10000,
} SomeEnum;
