// https://issues.dlang.org/show_bug.cgi?id=22607

float x = 0.f + 0.F + 0.l + 0.L;
float y = 1.f + 2.F + 3.l + 4.L;
