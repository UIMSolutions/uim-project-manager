// REQUIRED_ARGS: -o- -H -Hd${RESULTS_DIR}/compilable

// https://issues.dlang.org/show_bug.cgi?id=22728

typedef struct S { } S;
