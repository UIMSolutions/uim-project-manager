// https://issues.dlang.org/show_bug.cgi?id=22728

typedef enum E { A } F;
