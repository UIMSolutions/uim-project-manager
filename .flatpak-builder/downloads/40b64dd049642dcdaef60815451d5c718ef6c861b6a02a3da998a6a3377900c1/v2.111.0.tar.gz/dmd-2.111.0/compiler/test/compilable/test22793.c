// https://issues.dlang.org/show_bug.cgi?id=22793

__import core.stdc.stdio;
__import core.stdc.stdlib;
