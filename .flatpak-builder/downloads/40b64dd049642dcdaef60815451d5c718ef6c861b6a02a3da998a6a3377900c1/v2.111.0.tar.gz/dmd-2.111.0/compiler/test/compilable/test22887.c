/* https://issues.dlang.org/show_bug.cgi?id=22887
 */

enum A { a };
typedef enum A B;
