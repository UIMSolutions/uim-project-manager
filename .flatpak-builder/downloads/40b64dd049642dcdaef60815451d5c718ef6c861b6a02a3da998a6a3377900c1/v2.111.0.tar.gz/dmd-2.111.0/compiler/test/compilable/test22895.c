// https://issues.dlang.org/show_bug.cgi?id=22895

double x = 1.e6 + 1.E3;
