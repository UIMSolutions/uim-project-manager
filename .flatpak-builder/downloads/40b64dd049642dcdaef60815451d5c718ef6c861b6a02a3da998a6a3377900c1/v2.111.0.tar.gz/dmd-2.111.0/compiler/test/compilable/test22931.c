// https://issues.dlang.org/show_bug.cgi?id=22931

void fn()
{
    0;
}
