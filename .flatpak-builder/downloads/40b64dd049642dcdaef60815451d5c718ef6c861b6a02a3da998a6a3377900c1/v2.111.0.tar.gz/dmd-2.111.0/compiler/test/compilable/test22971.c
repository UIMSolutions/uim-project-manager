/* https://issues.dlang.org/show_bug.cgi?id=22971
 */

         char aaa[1] = "";
unsigned char bbb[1] = "";
  signed char ccc[1] = "";
