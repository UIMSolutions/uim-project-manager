/* https://issues.dlang.org/show_bug.cgi?id=23008
 */

struct {} a;
union {} b;
