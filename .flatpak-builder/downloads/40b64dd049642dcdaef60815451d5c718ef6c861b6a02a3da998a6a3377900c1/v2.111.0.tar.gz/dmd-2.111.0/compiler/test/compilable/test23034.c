// EXTRA_SOURCES: imports/test23034b.c

struct S1 {
        int field1;
};
struct S1 *const unused;
