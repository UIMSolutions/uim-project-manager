// https://issues.dlang.org/show_bug.cgi?id=23622

int FP_NAN = 0;
#define FP_NAN 0

enum E { ENUM = 0 };
#define ENUM 0
