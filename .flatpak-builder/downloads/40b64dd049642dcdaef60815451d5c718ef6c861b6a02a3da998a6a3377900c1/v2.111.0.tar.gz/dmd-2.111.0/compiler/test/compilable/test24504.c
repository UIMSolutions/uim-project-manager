// REQUIRED_ARGS: -g

typedef enum
{
    HasIntAndUIntValuesInt = 0,
    HasIntAndUIntValuesUInt = 0x80000000
} HasIntAndUIntValues;
