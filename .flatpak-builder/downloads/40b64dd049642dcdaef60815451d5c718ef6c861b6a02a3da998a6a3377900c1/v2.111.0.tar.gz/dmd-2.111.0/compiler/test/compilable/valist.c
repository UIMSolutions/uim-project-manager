// https://issues.dlang.org/show_bug.cgi?id=21974

typedef __builtin_va_list va_list;
