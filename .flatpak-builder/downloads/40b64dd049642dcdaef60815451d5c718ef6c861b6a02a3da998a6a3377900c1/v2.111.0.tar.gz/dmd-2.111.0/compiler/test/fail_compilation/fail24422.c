/*
TEST_OUTPUT:
---
fail_compilation/fail24422.c(7): Error: type-specifier missing for declaration of `a`
---
*/
void f24422(a) a; { }
