struct S22749
{
    int field : 1;
};
