#define __extension__ /* remove keyword from preprocessed code. */

#include <stdint.h>

uint32_t someCodeInC(uint32_t a, uint32_t b)
{
    return a + b;
}
