#import <Foundation/Foundation.h>

@interface Foo : NSObject
-(int) foo;
@end

@implementation Foo
-(int) foo
{
    return 3;
}
@end
