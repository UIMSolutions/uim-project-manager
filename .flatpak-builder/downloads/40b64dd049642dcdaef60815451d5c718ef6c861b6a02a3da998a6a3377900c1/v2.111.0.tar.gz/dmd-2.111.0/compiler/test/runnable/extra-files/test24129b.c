
inline int dup()
{
    return 73;
}

void *abc()
{
    return &dup;
}
