
struct B
{
    unsigned int x : 1;
//    unsigned int x;
};
