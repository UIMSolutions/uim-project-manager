// https://issues.dlang.org/show_bug?id=23837

struct stbrp_context
{
	int width;
	int height;
	int align;
	int init_mode;
	int heuristic;
};
