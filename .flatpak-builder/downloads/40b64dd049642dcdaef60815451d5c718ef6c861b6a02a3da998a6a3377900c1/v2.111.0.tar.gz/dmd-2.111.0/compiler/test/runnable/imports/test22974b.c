int xxx;

int ccc() { return 1; }
