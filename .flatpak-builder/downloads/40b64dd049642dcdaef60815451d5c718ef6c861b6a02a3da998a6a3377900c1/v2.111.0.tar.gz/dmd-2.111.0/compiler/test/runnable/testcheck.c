
int main()
{
    int i = 3;
    __check(i == 3);
    return 0;
}
