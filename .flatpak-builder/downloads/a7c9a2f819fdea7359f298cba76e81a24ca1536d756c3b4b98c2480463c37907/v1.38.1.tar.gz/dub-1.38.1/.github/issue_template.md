<!--
Please search for existing solutions to your problem before filling out this bug report template.

- Issue list: https://github.com/dlang/dub/issues?q=is%3Aissue
- Cookbook: https://github.com/dlang/dub/wiki/Cookbook
- Stack Overflow: https://stackoverflow.com/questions/tagged/dub
-->

### System information
<!-- replace examples with your info -->
- **dub version**: (e.g. dub 1.3.0)
- **OS Platform and distribution**: (e.g. Windows 10, Linux Ubuntu 16.04)
- **compiler version** (e.g. dmd-2.074.1)

### Bug Description

### How to reproduce?

### Expected Behavior

### Logs
